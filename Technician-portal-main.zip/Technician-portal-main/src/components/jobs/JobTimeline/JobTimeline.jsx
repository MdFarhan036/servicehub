import "./JobTimeline.css";

export default function JobTimeline({ steps }) {
  return (
    <ul className="job-timeline">
      {steps.map((s, i) => (
        <li key={i} className={`timeline-item ${s.done ? "done" : ""}`}>
          <span className="timeline-dot" />
          <div>
            <p className="timeline-step">{s.step}</p>
            <span className="timeline-time">{s.time}</span>
          </div>
        </li>
      ))}
    </ul>
  );
}
