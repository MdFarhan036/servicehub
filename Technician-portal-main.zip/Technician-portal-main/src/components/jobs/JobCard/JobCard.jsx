import { useNavigate } from "react-router-dom";
import { FiMapPin, FiClock, FiChevronRight } from "react-icons/fi";
import StatusBadge from "../../common/StatusBadge/StatusBadge";
import "./JobCard.css";

export default function JobCard({ job }) {
  const navigate = useNavigate();

  return (
    <div className="job-card card" onClick={() => navigate(`/jobs/${job.id}`)}>
      <div className="job-card-top">
        <div>
          <h4>{job.service}</h4>
          <span className="job-id">{job.id}</span>
        </div>
        <StatusBadge status={job.status} />
      </div>

      <div className="job-card-meta">
        <span><FiMapPin /> {job.address}</span>
        <span><FiClock /> {job.date} · {job.time}</span>
      </div>

      <div className="job-card-footer">
        <span className="job-customer">{job.customer}</span>
        <span className="job-price">{job.price ? `₹${job.price}` : "—"}</span>
        <FiChevronRight className="job-arrow" />
      </div>
    </div>
  );
}
