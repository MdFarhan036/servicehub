import { FiMenu, FiBell, FiChevronDown } from "react-icons/fi";
import { technicianProfile } from "../../../data/technicianData";
import "./Header.css";

export default function Header({ onMenuClick, title }) {
  return (
    <header className="topbar">
      <div className="topbar-left">
        <button className="menu-btn" onClick={onMenuClick}><FiMenu /></button>
        <h2 className="topbar-title">{title}</h2>
      </div>

      <div className="topbar-right">
        <button className="icon-btn">
          <FiBell />
          <span className="notif-dot" />
        </button>
        <div className="user-chip">
          <div className="user-avatar">{technicianProfile.name.charAt(0)}</div>
          <div className="user-info">
            <span className="user-name">{technicianProfile.name}</span>
            <span className="user-role">{technicianProfile.category}</span>
          </div>
          <FiChevronDown className="chip-caret" />
        </div>
      </div>
    </header>
  );
}
