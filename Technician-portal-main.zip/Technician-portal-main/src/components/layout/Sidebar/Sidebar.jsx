import { NavLink } from "react-router-dom";
import {
  FiGrid, FiBriefcase, FiUser, FiFileText, FiDollarSign,
  FiBell, FiSettings, FiLogOut,
} from "react-icons/fi";
import "./Sidebar.css";

const navItems = [
  { to: "/dashboard", label: "Dashboard", icon: FiGrid },
  { to: "/jobs", label: "Jobs", icon: FiBriefcase },
  { to: "/earnings", label: "Earnings", icon: FiDollarSign },
  { to: "/documents", label: "Documents", icon: FiFileText },
  { to: "/notifications", label: "Notifications", icon: FiBell },
  { to: "/profile", label: "Profile", icon: FiUser },
  { to: "/settings", label: "Settings", icon: FiSettings },
];

export default function Sidebar({ open }) {
  return (
    <aside className={`sidebar ${open ? "sidebar-open" : ""}`}>
      <div className="sidebar-logo">
        <div className="logo-mark">S</div>
        <span>ServiceHub</span>
      </div>

      <nav className="sidebar-nav">
        {navItems.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) => `sidebar-link ${isActive ? "active" : ""}`}
          >
            <Icon className="sidebar-icon" />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>

      <button
        className="sidebar-link logout"
        onClick={() => {
          localStorage.removeItem("sh_technician_auth");
          window.location.href = "/login";
        }}
      >
        <FiLogOut className="sidebar-icon" />
        <span>Logout</span>
      </button>
    </aside>
  );
}
