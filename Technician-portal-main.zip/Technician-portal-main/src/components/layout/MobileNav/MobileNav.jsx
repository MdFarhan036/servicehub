import { NavLink } from "react-router-dom";
import { FiGrid, FiBriefcase, FiDollarSign, FiUser, FiBell } from "react-icons/fi";
import "./MobileNav.css";

const items = [
  { to: "/dashboard", icon: FiGrid, label: "Home" },
  { to: "/jobs", icon: FiBriefcase, label: "Jobs" },
  { to: "/earnings", icon: FiDollarSign, label: "Earnings" },
  { to: "/notifications", icon: FiBell, label: "Alerts" },
  { to: "/profile", icon: FiUser, label: "Profile" },
];

export default function MobileNav() {
  return (
    <nav className="mobile-nav">
      {items.map(({ to, icon: Icon, label }) => (
        <NavLink key={to} to={to} className={({ isActive }) => `mnav-item ${isActive ? "active" : ""}`}>
          <Icon />
          <span>{label}</span>
        </NavLink>
      ))}
    </nav>
  );
}
