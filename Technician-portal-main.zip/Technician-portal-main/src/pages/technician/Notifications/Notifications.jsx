import { FiBell } from "react-icons/fi";
import { notifications } from "../../../data/technicianData";
import "./Notifications.css";

export default function Notifications() {
  return (
    <div>
      <h1 className="notif-title">Notifications</h1>
      <div className="notif-list">
        {notifications.map((n) => (
          <div key={n.id} className={`card notif-item ${!n.read ? "unread" : ""}`}>
            <div className="notif-icon"><FiBell /></div>
            <div className="notif-body">
              <p className="notif-heading">{n.title}</p>
              <p className="notif-message text-gray">{n.message}</p>
              <span className="notif-time">{n.time}</span>
            </div>
            {!n.read && <span className="notif-dot-indicator" />}
          </div>
        ))}
      </div>
    </div>
  );
}
