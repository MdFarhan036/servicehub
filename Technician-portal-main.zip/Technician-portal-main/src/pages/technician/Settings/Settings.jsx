import { useState } from "react";
import Button from "../../../components/common/Button/Button";
import "./Settings.css";

export default function Settings() {
  const [toggles, setToggles] = useState({ jobAlerts: true, promo: false, sms: true });

  function toggle(key) {
    setToggles((prev) => ({ ...prev, [key]: !prev[key] }));
  }

  return (
    <div className="settings-page">
      <h1 className="settings-title">Settings</h1>

      <div className="card settings-block">
        <h4>Notification Preferences</h4>
        {[
          { key: "jobAlerts", label: "New job alerts" },
          { key: "promo", label: "Promotional messages" },
          { key: "sms", label: "SMS notifications" },
        ].map((item) => (
          <div className="settings-row" key={item.key}>
            <span>{item.label}</span>
            <button
              className={`toggle-switch ${toggles[item.key] ? "on" : ""}`}
              onClick={() => toggle(item.key)}
            >
              <span className="toggle-knob" />
            </button>
          </div>
        ))}
      </div>

      <div className="card settings-block">
        <h4>Change Password</h4>
        <div className="settings-form">
          <input type="password" placeholder="Current password" />
          <input type="password" placeholder="New password" />
          <Button size="md">Update Password</Button>
        </div>
      </div>
    </div>
  );
}
