import { technicianProfile } from "../../../data/technicianData";
import StatusBadge from "../../../components/common/StatusBadge/StatusBadge";
import Button from "../../../components/common/Button/Button";
import "./Profile.css";

export default function Profile() {
  const t = technicianProfile;

  return (
    <div className="profile-page">
      <div className="profile-header card">
        <div className="profile-avatar">{t.name.charAt(0)}</div>
        <div className="profile-header-info">
          <h2>{t.name}</h2>
          <p className="text-gray">{t.category} · {t.experience} experience</p>
          <StatusBadge status={t.status} />
        </div>
        <Button variant="secondary">Edit Profile</Button>
      </div>

      <div className="profile-grid">
        <div className="card profile-block">
          <h4>Contact Information</h4>
          <div className="profile-row"><span>Email</span><span>{t.email}</span></div>
          <div className="profile-row"><span>Phone</span><span>{t.phone}</span></div>
          <div className="profile-row"><span>City</span><span>{t.city}</span></div>
        </div>

        <div className="card profile-block">
          <h4>Service Areas</h4>
          <div className="profile-tags">
            {t.serviceAreas.map((a) => <span key={a} className="profile-tag">{a}</span>)}
          </div>
        </div>

        <div className="card profile-block">
          <h4>Stats</h4>
          <div className="profile-row"><span>Total Jobs</span><span>{t.totalJobs}</span></div>
          <div className="profile-row"><span>Rating</span><span>{t.rating} ★</span></div>
          <div className="profile-row"><span>Joined</span><span>{t.joinedOn}</span></div>
        </div>
      </div>
    </div>
  );
}
