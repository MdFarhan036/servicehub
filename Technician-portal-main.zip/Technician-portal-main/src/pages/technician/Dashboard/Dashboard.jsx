import { FiBriefcase, FiCheckCircle, FiDollarSign, FiStar } from "react-icons/fi";
import { jobsData } from "../../../data/jobsData";
import { technicianProfile } from "../../../data/technicianData";
import JobCard from "../../../components/jobs/JobCard/JobCard";
import "./Dashboard.css";

export default function Dashboard() {
  const activeJobs = jobsData.filter((j) => j.status === "In Progress" || j.status === "Pending");
  const completed = jobsData.filter((j) => j.status === "Completed").length;
  const totalEarnings = jobsData.filter((j) => j.status === "Completed").reduce((s, j) => s + j.price, 0);

  const stats = [
    { label: "Active Jobs", value: activeJobs.length, icon: FiBriefcase, color: "info" },
    { label: "Completed", value: completed, icon: FiCheckCircle, color: "success" },
    { label: "Earnings (Job total)", value: `₹${totalEarnings}`, icon: FiDollarSign, color: "primary" },
    { label: "Rating", value: technicianProfile.rating, icon: FiStar, color: "warning" },
  ];

  return (
    <div>
      <div className="dash-welcome">
        <h1>Welcome back, {technicianProfile.name.split(" ")[0]} 👋</h1>
        <p className="text-gray">Here's what's happening with your jobs today.</p>
      </div>

      <div className="stats-grid">
        {stats.map((s) => (
          <div className="stat-card card" key={s.label}>
            <div className={`stat-icon stat-${s.color}`}><s.icon /></div>
            <div>
              <p className="stat-value">{s.value}</p>
              <p className="stat-label">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="dash-section">
        <div className="dash-section-head">
          <h3>Recent Jobs</h3>
        </div>
        {jobsData.slice(0, 3).map((job) => (
          <JobCard key={job.id} job={job} />
        ))}
      </div>
    </div>
  );
}
