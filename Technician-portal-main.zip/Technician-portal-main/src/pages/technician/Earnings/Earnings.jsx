import { FiDollarSign, FiTrendingUp, FiCalendar } from "react-icons/fi";
import { earningsData } from "../../../data/jobsData";
import "./Earnings.css";

export default function Earnings() {
  const total = earningsData.reduce((s, e) => s + e.amount, 0);
  const thisMonth = earningsData.reduce((s, e) => s + e.amount, 0);

  return (
    <div>
      <h1 className="earnings-title">Earnings</h1>

      <div className="earnings-summary">
        <div className="card earnings-stat">
          <FiDollarSign className="es-icon" />
          <div><p className="es-value">₹{total}</p><span>Total Earnings</span></div>
        </div>
        <div className="card earnings-stat">
          <FiTrendingUp className="es-icon" />
          <div><p className="es-value">₹{thisMonth}</p><span>This Month</span></div>
        </div>
        <div className="card earnings-stat">
          <FiCalendar className="es-icon" />
          <div><p className="es-value">{earningsData.length}</p><span>Paid Jobs</span></div>
        </div>
      </div>

      <div className="card earnings-table-wrap">
        <table className="earnings-table">
          <thead>
            <tr><th>Job ID</th><th>Service</th><th>Date</th><th>Status</th><th>Amount</th></tr>
          </thead>
          <tbody>
            {earningsData.map((e) => (
              <tr key={e.id}>
                <td>{e.id}</td>
                <td>{e.service}</td>
                <td>{e.date}</td>
                <td><span className="paid-pill">{e.status}</span></td>
                <td className="amount-cell">₹{e.amount}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
