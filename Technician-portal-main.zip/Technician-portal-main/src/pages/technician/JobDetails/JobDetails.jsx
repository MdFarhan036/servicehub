import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { FiArrowLeft, FiPhone, FiMapPin, FiCalendar } from "react-icons/fi";
import { jobsData } from "../../../data/jobsData";
import StatusBadge from "../../../components/common/StatusBadge/StatusBadge";
import JobTimeline from "../../../components/jobs/JobTimeline/JobTimeline";
import MediaViewer from "../../../components/jobs/MediaViewer/MediaViewer";
import Button from "../../../components/common/Button/Button";
import "./JobDetails.css";

export default function JobDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const job = jobsData.find((j) => j.id === id);
  const [tab, setTab] = useState("overview");

  if (!job) {
    return (
      <div>
        <p>Job not found.</p>
        <Button onClick={() => navigate("/jobs")}>Back to Jobs</Button>
      </div>
    );
  }

  return (
    <div className="job-details">
      <button className="back-link" onClick={() => navigate("/jobs")}>
        <FiArrowLeft /> Back to Jobs
      </button>

      <div className="job-details-header card">
        <div>
          <h2>{job.service}</h2>
          <span className="job-id">{job.id}</span>
        </div>
        <StatusBadge status={job.status} />
      </div>

      <div className="job-details-grid">
        <div className="job-details-main card">
          <div className="jd-tabs">
            {["overview", "timeline", "media"].map((t) => (
              <button key={t} className={tab === t ? "active" : ""} onClick={() => setTab(t)}>
                {t.charAt(0).toUpperCase() + t.slice(1)}
              </button>
            ))}
          </div>

          {tab === "overview" && (
            <div className="jd-overview">
              <p><strong>Customer:</strong> {job.customer}</p>
              <p><strong>Notes:</strong> {job.notes}</p>
              <div className="jd-info-row"><FiMapPin /> {job.address}</div>
              <div className="jd-info-row"><FiCalendar /> {job.date} · {job.time}</div>
              <div className="jd-info-row"><FiPhone /> {job.phone}</div>
            </div>
          )}

          {tab === "timeline" && <JobTimeline steps={job.timeline} />}
          {tab === "media" && <MediaViewer media={job.media} />}
        </div>

        <div className="job-details-side card">
          <h4>Job Amount</h4>
          <p className="jd-price">{job.price ? `₹${job.price}` : "—"}</p>
          <div className="jd-actions">
            {job.status === "Pending" && <Button fullWidth>Accept Job</Button>}
            {job.status === "In Progress" && <Button fullWidth>Mark as Completed</Button>}
            <Button fullWidth variant="secondary">Call Customer</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
