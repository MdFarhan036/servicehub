import { useState } from "react";
import { jobsData } from "../../../data/jobsData";
import JobCard from "../../../components/jobs/JobCard/JobCard";
import "./Jobs.css";

const filters = ["All", "Pending", "In Progress", "Completed", "Cancelled"];

export default function Jobs() {
  const [active, setActive] = useState("All");

  const filtered = active === "All" ? jobsData : jobsData.filter((j) => j.status === active);

  return (
    <div>
      <h1 className="jobs-title">My Jobs</h1>

      <div className="jobs-filters">
        {filters.map((f) => (
          <button key={f} className={`filter-chip ${active === f ? "active" : ""}`} onClick={() => setActive(f)}>
            {f}
          </button>
        ))}
      </div>

      <div className="jobs-list">
        {filtered.length === 0 ? (
          <p className="text-gray">No jobs found for this filter.</p>
        ) : (
          filtered.map((job) => <JobCard key={job.id} job={job} />)
        )}
      </div>
    </div>
  );
}
