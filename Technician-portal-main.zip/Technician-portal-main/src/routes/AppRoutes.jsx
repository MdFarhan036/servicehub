import { Routes, Route, Navigate } from "react-router-dom";
import TechnicianLayout from "../layouts/TechnicianLayout/TechnicianLayout";

import Login from "../pages/technician/Login/Login";
import Register from "../pages/technician/Register/Register";
import Dashboard from "../pages/technician/Dashboard/Dashboard";
import Jobs from "../pages/technician/Jobs/Jobs";
import JobDetails from "../pages/technician/JobDetails/JobDetails";
import Profile from "../pages/technician/Profile/Profile";
import Documents from "../pages/technician/Documents/Documents";
import Earnings from "../pages/technician/Earnings/Earnings";
import Notifications from "../pages/technician/Notifications/Notifications";
import Settings from "../pages/technician/Settings/Settings";

function isAuthed() {
  return !!localStorage.getItem("sh_technician_auth");
}

function ProtectedRoute({ children }) {
  return isAuthed() ? children : <Navigate to="/login" replace />;
}

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      <Route
        element={
          <ProtectedRoute>
            <TechnicianLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/jobs" element={<Jobs />} />
        <Route path="/jobs/:id" element={<JobDetails />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/documents" element={<Documents />} />
        <Route path="/earnings" element={<Earnings />} />
        <Route path="/notifications" element={<Notifications />} />
        <Route path="/settings" element={<Settings />} />
      </Route>

      <Route path="/" element={<Navigate to={isAuthed() ? "/dashboard" : "/login"} replace />} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}
