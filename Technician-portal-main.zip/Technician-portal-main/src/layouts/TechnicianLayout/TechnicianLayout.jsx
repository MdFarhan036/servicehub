import { useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import Sidebar from "../../components/layout/Sidebar/Sidebar";
import Header from "../../components/layout/Header/Header";
import MobileNav from "../../components/layout/MobileNav/MobileNav";
import ChatbotButton from "../../components/chatbot/ChatbotButton/ChatbotButton";
import ChatbotWindow from "../../components/chatbot/ChatbotWindow/ChatbotWindow";
import "./TechnicianLayout.css";

const titleMap = {
  "/dashboard": "Dashboard",
  "/jobs": "My Jobs",
  "/earnings": "Earnings",
  "/documents": "Documents",
  "/notifications": "Notifications",
  "/profile": "Profile",
  "/settings": "Settings",
};

export default function TechnicianLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const location = useLocation();

  const baseTitle = "/" + location.pathname.split("/")[1];
  const title = titleMap[baseTitle] || "Dashboard";

  return (
    <div className="layout-shell">
      {sidebarOpen && <div className="sidebar-backdrop" onClick={() => setSidebarOpen(false)} />}
      <Sidebar open={sidebarOpen} />

      <div className="layout-main">
        <Header onMenuClick={() => setSidebarOpen((s) => !s)} title={title} />
        <div className="layout-content page-fade">
          <Outlet />
        </div>
      </div>

      <MobileNav />

      <ChatbotButton onClick={() => setChatOpen((o) => !o)} open={chatOpen} />
      <ChatbotWindow isOpen={chatOpen} onClose={() => setChatOpen(false)} />
    </div>
  );
}
